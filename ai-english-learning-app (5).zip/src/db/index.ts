import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error(
    "DATABASE_URL is required. On Vercel add the Neon pooled connection string in Project → Settings → Environment Variables.",
  );
}

const isLocal = /(?:localhost|127\.0\.0\.1|::1)/.test(databaseUrl);
const requiresSsl =
  /sslmode=(?:require|verify-ca|verify-full)/i.test(databaseUrl) ||
  process.env.PGSSLMODE === "require" ||
  !isLocal;

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

/**
 * Serverless friendly pool:
 * - cached on globalThis so warm Vercel lambdas reuse connections,
 * - small pool + short idle timeouts so Neon (PgBouncer) does not run out of slots,
 * - SSL forced for remote hosts (Neon requires TLS).
 */
export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    max: Number(process.env.PG_POOL_MAX ?? 5),
    idleTimeoutMillis: 10_000,
    connectionTimeoutMillis: 10_000,
    allowExitOnIdle: true,
    ssl: requiresSsl ? { rejectUnauthorized: false } : undefined,
  });

pool.on("error", (error) => {
  console.error("[db] unexpected idle client error", error.message);
});

globalForDb.__arenaNextJsPostgresqlPool = pool;

export const db = drizzle(pool);
